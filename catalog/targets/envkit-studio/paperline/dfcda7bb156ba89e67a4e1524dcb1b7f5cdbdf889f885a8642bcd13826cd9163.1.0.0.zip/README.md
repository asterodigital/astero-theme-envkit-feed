# Paperline

Paperline is a small, dependency-free CMS theme. Its accent color and site name can be set in Theme Settings. Changes are released from Git tags matching the version in the theme manifest.
